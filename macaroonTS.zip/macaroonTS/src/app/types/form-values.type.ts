export type FormValuesType = {
  productTitle: string,
  customerName: string,
  phone: string
}
