export type AdvantagesType = {
  title: string,
  description: string
}
